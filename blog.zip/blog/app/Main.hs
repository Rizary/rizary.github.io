--------------------------------------------------------------------------------
-- {-# LANGUAGE DeriveDataTypeable #-}
{-# LANGUAGE OverloadedStrings #-}

module Main where

import           Blaze               as B
import           Control.Applicative ((<$>), (<*>))
import           Control.Monad       (filterM, forM_, void, when)
import           Data.Char           (isSpace)
import           Data.Function       (on)
import           Data.Generics       (everywhereM, mkM)
import           Data.List           as D (intercalate, intersperse, isInfixOf,
                                           isPrefixOf, reverse, sortBy)
import qualified Data.Map            as M
import           Data.Monoid         (mappend, mconcat, (<>))
import           Data.Time.Calendar  (toGregorian)
import           Data.Time.Clock     (getCurrentTime, utctDay)
import           Data.Time.Format    (formatTime)
import           Data.Time.LocalTime (getCurrentTimeZone, utcToLocalTime)
import           Hakyll
import           System.Directory    (createDirectoryIfMissing,
                                      doesDirectoryExist, doesFileExist,
                                      getDirectoryContents, renameDirectory,
                                      renameFile)
import           System.Environment  (getArgs)
import           System.FilePath     (addExtension, dropExtension, hasExtension,
                                      joinPath, replaceExtension,
                                      splitDirectories, takeBaseName,
                                      takeDirectory, (</>))
import           System.Locale       (defaultTimeLocale)
import           System.Process      (rawSystem, system)
import           Text.Pandoc         (HTMLMathMethod (..), Inline (..),
                                      ObfuscationMethod (..), Pandoc,
                                      WriterOptions (..))
import           Text.Regex.Posix    hiding (match)
-- import           TikZ


--------------------------------------------------------------------------------
-- | Jumlah artikel teaser yang ditampilkan dalam blog page yang terurut
--
articlesPerIndexPage :: Int
articlesPerIndexPage = 10


main :: IO ()
main = do
  args <- getArgs
  case args of
    ["publish", p]    -> putStrLn "Publish"
    _                 -> doHakyll

doHakyll = hakyll $ do

    -- Membaca semua templates.
    match "templates/*" $ compile templateBodyCompiler

    match "images/*" $ do
        route   idRoute
        compile copyFileCompiler

    match "css/*.css" $ do
        route   idRoute
        compile compressCssCompiler

    match "css/*.hs" $ do
      route $ setExtension "css"
      compile $ getResourceString >>= withItemBody (unixFilter "stack" ["exec","runghc"])


    tags <- buildTags "posts/*/*/*/*" (fromCapture "blog/tags/*.html")
    pctx <- postCtx tags


    tagsRules tags (makeTagList tags)

    -- Melakukan render pada blog posts berdasarkan markdown.
    --
    match "posts/*/*/*/*.markdown" $ do
        route $ postsRoute `composeRoutes` setExtension "html"
        compile $
          pandocCompiler
            >>= saveSnapshot "content"
            >>= loadAndApplyTemplate "templates/post.html" pctx
            >>= loadAndApplyTemplate "templates/default.html" pctx
            >>= relativizeUrls

    create ["index.html"] $ do
        route idRoute
        compile $
          makeItem B.indexPage
            >>= loadAndApplyTemplate "templates/default.html" simplePostCtx
            >>= relativizeUrls

    create ["blog/index.html"] $ do
          route idRoute
          compile $ do
            posts <- recentFirst =<< loadAllSnapshots "posts/*/*/*/*" "content"
            makeItem "" --B.blogIndex
              >>= loadAndApplyTemplate "templates/blog.html" (blogCtx posts)
              >>= loadAndApplyTemplate "templates/default.html" (blogCtx posts)
              >>= relativizeUrls

    where
      postsPattern = fromGlob "posts/*/*/*/*.markdown"
      postsRoute = gsubRoute "posts/" (const "blog/posts/")
--------------------------------------------------------------------------------
postCtx :: MonadMetadata m => Tags -> m (Context String)
postCtx tags =
  return $
      --functionField "testing" (\args _ -> error $ show args) `mappend`
      --functionField "teaser" teaserField `mappend`
      teaserField "teaser" "content" `mappend`
      tagsField "tags" tags `mappend`
      dateField "date" "%B %e, %Y" `mappend`
      defaultContext

blogCtx :: [Item String] -> Context String
blogCtx ctx =
  teaserField "teaser" "content" `mappend`
  constField "header" "Recent Post" `mappend`
  listField "posts" simplePostCtx (return ctx) `mappend`
  defaultContext

simplePostCtx :: Context String
simplePostCtx = dateField "date" "%B %e, %Y" `mappend` defaultContext

postCompiler :: Context String -> Compiler (Item String)
postCompiler ctx =
    pandocCompiler
      >>= loadAndApplyTemplate "templates/post.html" ctx
      >>= loadAndApplyTemplate "templates/default.html" ctx
      >>= relativizeUrls

-- | Pandoc Writer options.
--
writeOptions :: WriterOptions
writeOptions = defaultHakyllWriterOptions
    { writerEmailObfuscation = NoObfuscation,
      writerHTMLMathMethod = MathML Nothing}

-- | Membetulkan tautan post yang menggunakan abbreviated forms
--
-- | Menjadikan badan postingan yang berada diatas tanda <!--MORE--> menjadi
-- sebuah teaser, kecuali untuk setiap text antara tanda <!--NOTEASERBEGIN-->> dan
-- <!--NOTEASEREND--> (untuk membuat gambar tidak masuk ke teaser)


-- readMoreField
readMoreField :: [String] -> Item String -> Compiler String
readMoreField _ i = do
  rte <- getRoute $ itemIdentifier i
  return $ case rte of
    Nothing -> ""
    Just r -> if "<!--MORE-->" `isInfixOf` itemBody i
      then readMoreLink r
      else ""
    where readMoreLink = B.htmlReadmore

postList :: Pattern
         -> ([Item String] -> Compiler [Item String])
         -> Context String
         -> String
         -> Compiler String
postList pattern preprocess' ctx tmpl = do
  postItemTpl <- loadBody $ fromFilePath $ "templates/" ++ tmpl ++ ".html"
  posts <- loadAll pattern
  processed <- preprocess' posts
  applyTemplateList postItemTpl ctx processed

makeTagList :: Tags -> String -> Pattern -> Rules ()
makeTagList tags tag pattern = do
  let title = "Posts tagged &#8216;" ++ tag ++ "&#8217;"
      pagetitle = "My Blog"
  route idRoute
  compile $ do
    list <- postList pattern recentFirst simplePostCtx "tagitem"
    makeItem ""
      >>= loadAndApplyTemplates ["tags", "default"]
            (constField "title" title `mappend`
             constField "pagetitle" pagetitle `mappend`
             constField "posts" list `mappend`
             defaultContext)
      >>= relativizeUrls

updatePostList :: IO ()
updatePostList = void $ system "find posts -name \\*.markdown > post-list"

loadAndApplyTemplates :: [String] -> Context String -> Item String -> Compiler (Item String)
loadAndApplyTemplates [c] ctx i =
  loadAndApplyTemplate (fromFilePath $ "templates/" ++ c ++ ".html") ctx i
loadAndApplyTemplates (c:cs) ctx i = do
    i' <- loadAndApplyTemplate (fromFilePath $ "templates/" ++ c ++ ".html") ctx i
    loadAndApplyTemplates cs ctx i'
