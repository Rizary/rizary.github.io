{-# LANGUAGE OverloadedStrings #-}

module Blaze where

import           Hakyll                          (toUrl)
import           Text.Blaze                      (toValue, (!))
import qualified Text.Blaze.Html.Renderer.Pretty as P
import           Text.Blaze.Html.Renderer.String (renderHtml)
import qualified Text.Blaze.Html5                as H
import qualified Text.Blaze.Html5.Attributes     as A

-----------------------------------------------------

indexPage :: String
indexPage = renderHtml $
                H.body $ do
                  H.div ! A.id "Test-Default" $ do
                    H.p " %body% "
                    H.p " %test% "

                  H.div ! A.id "Test-2-Default" $ do
                    H.p " %Again%"
                    H.p " %Yeah%"

blogIndex :: String
blogIndex = P.renderHtml $ do
                H.head $ do
                  H.title "Rizary"
                H.body $ do
                  H.div ! A.id "Test-Default" $ do
                    H.p " %body% "
                    H.p " %test% "

                  H.div ! A.id "Test-2-Default" $ do
                    H.p " %Again%"
                    H.p " %Yeah%"


indexNavLink :: Int -> Int -> Int -> String
indexNavLink n d maxn = renderHtml ref
    where ref = if refPage == "" then ""
                else H.a ! A.href (toValue $ toUrl $ refPage) $
                     H.preEscapedToMarkup lab
          lab :: String
          lab = if d > 0 then "&laquo; OLDER POSTS" else "NEWER POSTS $raquo;"
          refPage = if(n+d<1 || n + d > maxn) then ""
                    else case n + d of
                         1 -> "/blog/posts"
                         _ -> "/blog/posts" ++ (show $ n + d) ++ "/"

htmlReadmore :: String -> String
htmlReadmore r' =
    renderHtml $ H.div ! A.class_ "readmore" $
    H.a ! A.href (toValue $ "/" ++ r') $
    H.preEscapedToMarkup ("Read more &raquo;" :: String)


posty tag (Just fp)=
           Just $ H.span ! A.class_ "tag"
                $ H.a ! A.href (toValue $ toUrl fp) $ H.toHtml tag

renderTheTagCloud tag url size count minimum' maximum' =
    renderHtml $ H.span ! A.class_ "tagCloud" !
    A.style (toValue $ "font-size: " ++ size count minimum' maximum') $
    H.a ! A.href (toValue url) $ H.toHtml tag
